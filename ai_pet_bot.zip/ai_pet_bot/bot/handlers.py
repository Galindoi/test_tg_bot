# This will include commands like /add_pet, /list_pets etc.
# Placeholder
def register_handlers(dp, bot):
    pass