# OpenAI GPT integration placeholder
def get_advice(prompt):
    return 'Пример совета по уходу за питомцем...'