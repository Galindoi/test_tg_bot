# Scheduler placeholder
def setup_scheduler(bot):
    pass